ToyotechICT Solutions. 2020

Enjoy this project. Just extract and run
Run weatherApp .

Note, leave file in same directory as icons. Do not move the app